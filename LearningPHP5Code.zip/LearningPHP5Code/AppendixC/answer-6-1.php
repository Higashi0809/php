var_dump($_POST) prints:
array(4) {
  ["noodle"]=>
  string(14) "barbecued pork"
  ["sweet"]=>
  array(2) {
    [0]=>
    string(4) "puff"
    [1]=>
    string(8) "ricemeat"
  }
  ["sweet_q"]=>
  string(1) "4"
  ["submit"]=>
  string(5) "Order"
}
The opening PHP tag should be <?php. There should not be a space between <? and php.
The string 'I'm fine' should either be enclosed in double quotes ("I'm fine") or the apostrophe should be escaped ('I\'m fine').
The closing PHP tag should be ?&gt;, not ??&gt;.
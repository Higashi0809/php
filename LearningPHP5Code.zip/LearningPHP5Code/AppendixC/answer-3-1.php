false
true
true
false
false
true
true
$first_name = 'James';
$last_name = 'McCawley';
$full_name = "$first_name $last_name";
print $full_name;
print strlen($full_name);
; Change price to 5.50 in all rows of the table
UPDATE dishes SET price = 5.50

; Change is_spicy to 1 in all rows of the table
UPDATE dishes SET is_spicy = 1
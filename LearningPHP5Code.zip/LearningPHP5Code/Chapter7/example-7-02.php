require 'DB.php';
$db = DB::connect('mysql://penguin:top^hat@db.example.com/restaurant');
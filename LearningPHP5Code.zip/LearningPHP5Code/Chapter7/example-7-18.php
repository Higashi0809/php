UPDATE tablename SET column1=value1[, column2=value2,
     column3=value3, ...] [WHERE where_clause]
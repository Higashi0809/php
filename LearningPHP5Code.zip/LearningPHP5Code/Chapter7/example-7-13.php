INSERT INTO dishes (dish_id, dish_name, price, is_spicy)
    VALUES (2, 'General Tso\'s Chicken', 6.75, 1)
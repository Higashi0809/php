; Delete rows in which price is greater than 10.00
DELETE FROM dishes WHERE price > 10.00

; Delete rows in which dish_name is exactly "Walnut Bun"
DELETE FROM dishes WHERE dish_name = 'Walnut Bun'
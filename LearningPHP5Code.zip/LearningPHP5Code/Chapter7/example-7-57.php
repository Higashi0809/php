$db = mysqli_connect('db.example.com','hunter','w)mp3s','restaurant');
if (! $db) { die("Can't connect: " . mysqli_connect_error()); }
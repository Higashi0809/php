INSERT INTO dishes (dish_name, is_spicy)
    VALUES ('Salt Baked Scallops', 0)
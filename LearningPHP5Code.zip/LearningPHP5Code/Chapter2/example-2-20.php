
// Add one to $birthday
$birthday = $birthday + 1;
// Add another one to $birthday
++$birthday;

// Subtract 1 from $years_left
$years_left = $years_left - 1;
// Subtract another 1 from $years_left
--$years_left;

if ($_POST['email'] == 'president@whitehouse.gov') {
   print "Welcome, Mr. President.";
}
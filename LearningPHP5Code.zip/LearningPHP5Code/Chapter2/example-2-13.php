print 'Card: XX';
print substr($_POST['card'],-4,4);
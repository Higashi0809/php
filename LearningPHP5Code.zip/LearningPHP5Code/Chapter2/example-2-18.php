
// Add 3 the regular way
$price = $price + 3;
// Add 3 with the combined operator
$price += 3; 

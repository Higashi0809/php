print "Title: " . $xml->channel->item[0]->title . "\n";
print "Title: " . $xml->channel->item[1]->title . "\n";
print "Title: " . $xml->channel->item[2]->title . "\n";
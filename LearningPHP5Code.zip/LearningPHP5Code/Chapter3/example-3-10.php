
if ($word < 'baa') {
    print "Your word probably starts with 'A'.";
}
if ($word >= 'zoo') {
    print "Your word could be zoo or zymurgy, but not zone.";
}

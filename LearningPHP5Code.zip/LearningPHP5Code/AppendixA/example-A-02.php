require 'DB.php';
if (class_exists('DB')) {
    print "ok";
} else {
    print "failed";
}
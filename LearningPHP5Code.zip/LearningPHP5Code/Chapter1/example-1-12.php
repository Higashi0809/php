<?php
print        "Too many spaces"           ;
print"Too few spaces";
print "Just the right amount of spaces";
?>

<?php print "The population of the US is about:";
print number_format(285266237);
?>
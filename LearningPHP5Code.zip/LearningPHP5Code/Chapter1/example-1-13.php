// These four lines all do the same thing
print number_format(285266237);
PRINT Number_Format(285266237);
Print number_format(285266237);
pRiNt NUMBER_FORMAT(285266237);

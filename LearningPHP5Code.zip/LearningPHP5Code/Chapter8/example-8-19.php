<html>
<head>Choose Your Site Version</head>
<body>
<?php
setcookie('seen_intro', 1);
?>
<a href="/basic.php">Basic</a>
 or 
<a href="/advanced.php">Advanced</a>
</body>
</html>
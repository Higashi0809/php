<?php
ini_set('session.gc_probability',100); // 100% : clean up on every request
session_start();
?>
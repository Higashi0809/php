<?php
ini_set('session.gc_maxlifetime',600'); // 600 seconds == ten minutes
session_start();
?>
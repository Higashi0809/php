if (strlen($_POST['email']) == 0) {
   $errors[] = "You must enter an e-mail address.";
}
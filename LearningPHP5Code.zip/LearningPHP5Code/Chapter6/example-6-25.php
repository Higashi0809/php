print '<textarea name="comments">';
print htmlentities($defaults['comments']);
print '</textarea>';
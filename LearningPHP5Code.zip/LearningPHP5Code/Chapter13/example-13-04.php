<OBJECT classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"
 codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0"
 WIDTH="300" HEIGHT="300">
 <PARAM NAME=movie VALUE="ming.php">
 <PARAM NAME=bgcolor VALUE="#ffffff"> 
 <EMBED src="ming.php" bgcolor="#ffffff" WIDTH="300" HEIGHT="300"
 TYPE="application/x-shockwave-flash" PLUGINSPAGE="http://www.macromedia.com/go/getflashplayer"></EMBED>
</OBJECT>
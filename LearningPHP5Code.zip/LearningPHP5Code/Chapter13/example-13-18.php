$perl = new Perl();

$perl->eval('print "This is Perl!";');
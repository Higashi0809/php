print 'strftime() says: ';
print strftime('%c');
print "\n";
print 'date() says:';
print date('r');
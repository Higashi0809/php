$number_to_display = number_format(285266237);
print "The population of the US is about: $number_to_display";